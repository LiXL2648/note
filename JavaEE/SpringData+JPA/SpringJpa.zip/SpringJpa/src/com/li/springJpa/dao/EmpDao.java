package com.li.springJpa.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.li.springJpa.entity.Emp;

@Repository
public class EmpDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	public void save(Emp emp) {
		entityManager.persist(emp);
	}
}
