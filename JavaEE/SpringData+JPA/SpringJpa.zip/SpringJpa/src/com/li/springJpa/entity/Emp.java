package com.li.springJpa.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Table(name = "emp")
@Entity
public class Emp {

	private Integer empId;
	private String empName;
	private String email;
	private Integer gender;
	private Date birthday;
	private Date createDate;

	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "emp_id")
	@Id
	public Integer getEmpId() {
		return empId;
	}

	@Column(name = "emp_name", nullable = false, length = 32)
	public String getEmpName() {
		return empName;
	}

	@Column(length = 50)
	public String getEmail() {
		return email;
	}

	@Column(length = 1)
	public Integer getGender() {
		return gender;
	}

	@Column(columnDefinition = "DATE")
	public Date getBirthday() {
		return birthday;
	}

	@Temporal(TemporalType.TIMESTAMP)
	public Date getCreateDate() {
		return createDate;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setGender(Integer gender) {
		this.gender = gender;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

}
