package com.li.springJpa.test;

import java.sql.SQLException;
import java.util.Date;

import javax.sql.DataSource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.li.springJpa.entity.Emp;
import com.li.springJpa.service.EmpService;
import com.li.springJpa.util.DateTimeUtil;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
public class TestSpringJpa {

	@Autowired
	private DataSource dataSource;
	
	@Autowired
	private EmpService empService;
	
	@Test
	public void testSave() {
		Emp emp1 = new Emp();
		emp1.setEmpName("LiXL");
		emp1.setEmail("LiXL@qq.com");
		emp1.setGender(1);
		emp1.setBirthday(DateTimeUtil.getDate("1996-05-04"));
		emp1.setCreateDate(new Date());
		
		Emp emp2 = new Emp();
		emp2.setEmpName("LiLX");
		emp2.setEmail("LiLX@qq.com");
		emp2.setGender(0);
		emp2.setBirthday(DateTimeUtil.getDate("1996-07-30"));
		emp2.setCreateDate(new Date());
		
		System.out.println(empService.getClass().getName());
		empService.save(emp1, emp2);
	}
	
	@Test
	public void testGetConnection() {
		try {
			System.out.println(dataSource.getConnection());
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
