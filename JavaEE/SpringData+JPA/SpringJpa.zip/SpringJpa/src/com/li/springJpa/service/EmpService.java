package com.li.springJpa.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.li.springJpa.dao.EmpDao;
import com.li.springJpa.entity.Emp;

@Service
public class EmpService {

	@Autowired
	private EmpDao empDao;
	
	@Transactional
	public void save(Emp emp1, Emp emp2) {
		empDao.save(emp1);
		empDao.save(emp2);
	}
}
