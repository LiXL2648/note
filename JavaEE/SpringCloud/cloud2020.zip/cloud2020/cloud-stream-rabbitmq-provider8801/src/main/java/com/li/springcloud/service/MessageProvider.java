package com.li.springcloud.service;

public interface MessageProvider {
    public String send();
}
