package com.li.security.config.auth;

public class MyConstants {

    public final static String CAPTCHA_SESSION_KEY = "captchaCode";

    public final static String SMS_SESSION_KEY = "smsCode";
}
