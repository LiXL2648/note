package com.zghky.waterCollection.service;

import com.zghky.waterCollection.domain.SysRole;

import java.util.List;

public interface SysRoleService {

    List<SysRole> selectAll();
}
