package com.ss.dao;

import com.ss.entities.GtList;
import java.util.List;

public interface GtListMapper {
    int deleteByPrimaryKey(Long id);

    int insert(GtList record);

    GtList selectByPrimaryKey(Long id);

    List<GtList> selectAll();

    int updateByPrimaryKey(GtList record);
}