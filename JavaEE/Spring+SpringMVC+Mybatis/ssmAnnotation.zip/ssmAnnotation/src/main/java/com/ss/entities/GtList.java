package com.ss.entities;

import java.io.Serializable;
import java.util.Date;

public class GtList implements Serializable {
    private Long id;

    private String gtNumber;

    private String note;

    private Integer gtStatus;

    private Long countryCodeId;

    private Long operatorCodeId;

    private Date indbTime;

    private Date updateTime;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getGtNumber() {
        return gtNumber;
    }

    public void setGtNumber(String gtNumber) {
        this.gtNumber = gtNumber == null ? null : gtNumber.trim();
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note == null ? null : note.trim();
    }

    public Integer getGtStatus() {
        return gtStatus;
    }

    public void setGtStatus(Integer gtStatus) {
        this.gtStatus = gtStatus;
    }

    public Long getCountryCodeId() {
        return countryCodeId;
    }

    public void setCountryCodeId(Long countryCodeId) {
        this.countryCodeId = countryCodeId;
    }

    public Long getOperatorCodeId() {
        return operatorCodeId;
    }

    public void setOperatorCodeId(Long operatorCodeId) {
        this.operatorCodeId = operatorCodeId;
    }

    public Date getIndbTime() {
        return indbTime;
    }

    public void setIndbTime(Date indbTime) {
        this.indbTime = indbTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}