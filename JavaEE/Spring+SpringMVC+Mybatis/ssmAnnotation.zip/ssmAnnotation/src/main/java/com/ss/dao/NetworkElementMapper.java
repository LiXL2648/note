package com.ss.dao;

import com.ss.entities.NetworkElement;
import java.util.List;

public interface NetworkElementMapper {
    int deleteByPrimaryKey(Long id);

    int insert(NetworkElement record);

    NetworkElement selectByPrimaryKey(Long id);

    List<NetworkElement> selectAll();

    int updateByPrimaryKey(NetworkElement record);
}