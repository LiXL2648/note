package com.ss.dao;

import com.ss.entities.InterOperator;
import java.util.List;

public interface InterOperatorMapper {
    int deleteByPrimaryKey(Long id);

    int insert(InterOperator record);

    InterOperator selectByPrimaryKey(Long id);

    List<InterOperator> selectAll();

    int updateByPrimaryKey(InterOperator record);
}