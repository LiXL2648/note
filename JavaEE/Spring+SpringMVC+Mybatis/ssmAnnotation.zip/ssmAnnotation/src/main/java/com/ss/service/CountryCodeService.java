package com.ss.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.ss.dao.CountryCodeMapper;
import com.ss.entities.CountryCode;

@Service
@CacheConfig(cacheNames = "countryCode", cacheManager = "countryCodeRedisCacheManager")
public class CountryCodeService {

	@Autowired
	private CountryCodeMapper countryCodeMapper;
	
	
	@Cacheable
	public CountryCode getCountryCode(Long id) {
		return countryCodeMapper.selectByPrimaryKey(id);
	}
}
