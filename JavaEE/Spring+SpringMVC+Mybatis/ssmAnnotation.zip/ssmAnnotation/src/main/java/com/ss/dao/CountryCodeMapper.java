package com.ss.dao;

import com.ss.entities.CountryCode;
import java.util.List;

public interface CountryCodeMapper {
    int deleteByPrimaryKey(Long id);

    int insert(CountryCode record);

    CountryCode selectByPrimaryKey(Long id);

    List<CountryCode> selectAll();

    int updateByPrimaryKey(CountryCode record);
}