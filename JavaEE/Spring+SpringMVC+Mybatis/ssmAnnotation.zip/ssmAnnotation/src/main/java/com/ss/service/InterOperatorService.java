package com.ss.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.ss.dao.InterOperatorMapper;
import com.ss.entities.InterOperator;

@Service
@CacheConfig(cacheNames = "interOperator", cacheManager = "interOperatorRedisCacheManager")
public class InterOperatorService {

	@Autowired
	private InterOperatorMapper interOperatorMapper;
	
	@Cacheable
	public InterOperator getInterOperator(Long id) {
		return interOperatorMapper.selectByPrimaryKey(id);
	}
}
