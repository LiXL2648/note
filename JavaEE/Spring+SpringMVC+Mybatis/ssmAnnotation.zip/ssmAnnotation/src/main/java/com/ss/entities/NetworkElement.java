package com.ss.entities;

import java.io.Serializable;
import java.util.Date;

public class NetworkElement implements Serializable {
    private Long id;

    private String nodeType;

    private String nodeId;

    private String gt;

    private String ip;

    private String vendorInfo;

    private String swhwVer;

    private Integer dualAccess;

    private String location;

    private String utcOffset;

    private String dstStart;

    private String dstEnd;

    private String note;

    private Integer networkElementStatus;

    private Long countryCodeId;

    private Date indbTime;

    private Date updateTime;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNodeType() {
        return nodeType;
    }

    public void setNodeType(String nodeType) {
        this.nodeType = nodeType == null ? null : nodeType.trim();
    }

    public String getNodeId() {
        return nodeId;
    }

    public void setNodeId(String nodeId) {
        this.nodeId = nodeId == null ? null : nodeId.trim();
    }

    public String getGt() {
        return gt;
    }

    public void setGt(String gt) {
        this.gt = gt == null ? null : gt.trim();
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip == null ? null : ip.trim();
    }

    public String getVendorInfo() {
        return vendorInfo;
    }

    public void setVendorInfo(String vendorInfo) {
        this.vendorInfo = vendorInfo == null ? null : vendorInfo.trim();
    }

    public String getSwhwVer() {
        return swhwVer;
    }

    public void setSwhwVer(String swhwVer) {
        this.swhwVer = swhwVer == null ? null : swhwVer.trim();
    }

    public Integer getDualAccess() {
        return dualAccess;
    }

    public void setDualAccess(Integer dualAccess) {
        this.dualAccess = dualAccess;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location == null ? null : location.trim();
    }

    public String getUtcOffset() {
        return utcOffset;
    }

    public void setUtcOffset(String utcOffset) {
        this.utcOffset = utcOffset == null ? null : utcOffset.trim();
    }

    public String getDstStart() {
        return dstStart;
    }

    public void setDstStart(String dstStart) {
        this.dstStart = dstStart == null ? null : dstStart.trim();
    }

    public String getDstEnd() {
        return dstEnd;
    }

    public void setDstEnd(String dstEnd) {
        this.dstEnd = dstEnd == null ? null : dstEnd.trim();
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note == null ? null : note.trim();
    }

    public Integer getNetworkElementStatus() {
        return networkElementStatus;
    }

    public void setNetworkElementStatus(Integer networkElementStatus) {
        this.networkElementStatus = networkElementStatus;
    }

    public Long getCountryCodeId() {
        return countryCodeId;
    }

    public void setCountryCodeId(Long countryCodeId) {
        this.countryCodeId = countryCodeId;
    }

    public Date getIndbTime() {
        return indbTime;
    }

    public void setIndbTime(Date indbTime) {
        this.indbTime = indbTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}