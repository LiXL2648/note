package com.ss.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.ss.entities.CountryCode;
import com.ss.service.CountryCodeService;

@RestController
public class CountryCodeController {
	
	@Autowired
	private CountryCodeService countryCodeService;

	@GetMapping("/countryCode/{id}")
	public CountryCode getCountryCode(@PathVariable("id") Long id) {
		return countryCodeService.getCountryCode(id);
	}
}
