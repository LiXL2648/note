package com.ss.dao;

import com.ss.entities.MccMnc;
import java.util.List;

public interface MccMncMapper {
    int deleteByPrimaryKey(Long id);

    int insert(MccMnc record);

    MccMnc selectByPrimaryKey(Long id);

    List<MccMnc> selectAll();

    int updateByPrimaryKey(MccMnc record);
}